package com.seecen.day02.extendsPac;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 14:39
 */
public class Student extends People{
    String stuNum;
    String instiute;

    public Student(){
        System.out.println("我是不带参数的构造方法");
    }

    public Student(String stuNum){
        super();
        this.stuNum = stuNum;
    }

    public Student(String stuNum, String instiute,String name,String sex,String IdCarNum) {
        super(name,sex,IdCarNum);
        this.stuNum = stuNum;
        this.instiute = instiute;
    }

    public String getStuNum() {
        return stuNum;
    }

    public void setStuNum(String stuNum) {
        this.stuNum = stuNum;
    }

    public String getInstiute() {
        return instiute;
    }

    public void setInstiute(String instiute) {
        this.instiute = instiute;
    }

    @Override
    public String toString() {
        return "Student{" +
                "stuNum='" + stuNum + '\'' +
                ", instiute='" + instiute + '\'' +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", IdCarNum='" + IdCarNum + '\'' +
                '}';
    }
}
