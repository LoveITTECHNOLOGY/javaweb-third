package com.seecen.day02.extendsPac;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 15:12
 */
public class Fa {
    public void method(){
        System.out.println("我是Fa的method");
    }
}
