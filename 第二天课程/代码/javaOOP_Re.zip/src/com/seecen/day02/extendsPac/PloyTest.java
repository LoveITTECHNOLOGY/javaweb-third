package com.seecen.day02.extendsPac;

import java.util.ArrayList;
import java.util.List;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 15:13
 */
public class PloyTest {
    public static void main(String[] args) {
        Ch ch = new Ch();
        ch.method();
        ch.loadMethod();
        ch.loadMethod(2);
        ch.loadMethod(3,"测试文本");
        Fa ch1 = new Ch();
        Fa ch2 = new Ch2();
        ((Ch) ch1).myMethod();
        ((Ch2) ch2).myMethod();
    }
}
