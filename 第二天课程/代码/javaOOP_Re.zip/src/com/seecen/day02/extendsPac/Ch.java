package com.seecen.day02.extendsPac;

import javax.swing.*;
import java.awt.*;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 15:12
 */
public class Ch extends Fa{
    public void myMethod(){
        System.out.println("我是Ch的myMethod");
    }

    @Override
    public void method() {
        System.out.println("我是重写之后Ch的method");
    }

    public void loadMethod(){
        System.out.println("我是loadMethod");
    }
    //OverLoad
    public void loadMethod(int i){
        System.out.println("我是loadMethod"+i);
    }

    public void loadMethod(int i,String myText){
        System.out.println("我是loadMethod"+i+",text:"+myText);
    }
}


