package com.seecen.day02.extendsPac;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 14:41
 */
public class Teacher extends People{
    String teaNum;
    String institute;

    public String getTeaNum() {
        return teaNum;
    }

    public void setTeaNum(String teaNum) {
        this.teaNum = teaNum;
    }

    public String getInstitute() {
        return institute;
    }

    public void setInstitute(String institute) {
        this.institute = institute;
    }


    @Override
    public String toString() {
        return "Teacher{" +
                "teaNum='" + teaNum + '\'' +
                ", institute='" + institute + '\'' +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", IdCarNum='" + IdCarNum + '\'' +
                '}';
    }
}
