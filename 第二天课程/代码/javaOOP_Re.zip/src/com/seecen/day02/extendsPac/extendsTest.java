package com.seecen.day02.extendsPac;

import javax.print.Doc;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 14:46
 */
public class extendsTest {
    public static void main(String[] args) {
        Student student = new Student();
        Teacher teacher = new Teacher();
        Doctor doctor = new Doctor();
        People people = new People();
        student.setName("stu");
        student.setInstiute("计算机与大数据科学学院");
        student.setSex("女");
        student.setStuNum("100101");
        student.setIdCarNum("362420000000000000");
        System.out.println(student);
        teacher.setName("tyy");
        System.out.println(teacher);
        people.setIdCarNum("362720000000000001");
        people.setName("people");
        people.setSex("男");
        System.out.println(people);
        (new Object()).toString();
    }
}
