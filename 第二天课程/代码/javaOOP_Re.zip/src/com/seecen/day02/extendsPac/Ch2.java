package com.seecen.day02.extendsPac;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 15:27
 */
public class Ch2 extends Fa {
    public void myMethod(){
        System.out.println("我是Ch2的myMethod");
    }
}
