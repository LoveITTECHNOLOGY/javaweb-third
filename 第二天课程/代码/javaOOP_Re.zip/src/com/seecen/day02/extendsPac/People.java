package com.seecen.day02.extendsPac;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 14:44
 */
public class People {
    String name;
    String sex;
    String IdCarNum;

    public People(){

    }
    public People(String name, String sex, String idCarNum) {
        this.name = name;
        this.sex = sex;
        this.IdCarNum = idCarNum;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        test();
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getIdCarNum() {
        return IdCarNum;
    }

    public void setIdCarNum(String idCarNum) {
        IdCarNum = idCarNum;
    }

    @Override
    public String toString() {
        return "People{" +
                "name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", IdCarNum='" + IdCarNum + '\'' +
                '}';
    }

    private void test(){
        System.out.println("testing...");
    }
}
