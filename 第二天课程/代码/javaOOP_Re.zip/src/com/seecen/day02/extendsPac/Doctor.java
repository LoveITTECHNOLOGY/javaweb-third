package com.seecen.day02.extendsPac;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 14:42
 */
public class Doctor extends People {
    String department;

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "Doctor{" +
                "department='" + department + '\'' +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", IdCarNum='" + IdCarNum + '\'' +
                '}';
    }
}
