package com.seecen.day02.homework;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 14:26
 */
public class PhoneTest {
    public static void main(String[] args) {
        Phone phone = new Phone();
        phone.setBrand("HUAWEI");
        phone.setColor("黑色");
        phone.setPrice(5988);
        System.out.println(phone);
        phone.sendMessage();
        phone.call();
    }
}
