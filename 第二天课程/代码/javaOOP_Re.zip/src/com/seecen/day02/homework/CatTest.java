package com.seecen.day02.homework;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 14:14
 */
public class CatTest {
    public static void main(String[] args) {
        Cat cat = new Cat();
        cat.setAge(4);
        cat.setName("小花");
        cat.setType("英国短毛猫");
        cat.setWeight(8);
        System.out.println("name:"+cat.getName());
        //直接将对象名进行打印时 如果没有重写该类的toString()
        //打印出来的内容是全类名+@+十六进制的地址值
        //如果重写了，则按照重写的来
        System.out.println(cat);
        cat.actCute();
        cat.eat();
    }
}
