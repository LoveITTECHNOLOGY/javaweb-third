package com.seecen.day02.homework;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 14:12
 */
public class Cat {
    private String name;
    private String type;
    private int age;
    private double weight;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void actCute(){
        System.out.println("小猫卖萌！");
    }

    public void eat(){
        System.out.println("小猫吃东西！");
    }

    @Override
    public String toString() {
        return "ToStringTest_Cat{" +
                "name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                '}';
    }
}
