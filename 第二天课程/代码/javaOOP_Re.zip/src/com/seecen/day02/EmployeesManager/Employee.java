package com.seecen.day02.EmployeesManager;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description: 员工类，描述员工信息
 * @create: 2020-11-24 16:22
 */
public class Employee {
    //约定:名字和年龄相同的员工为同一员工
    private int id;//唯一标识
    private String name;//名字
    private int age;//年龄

    //无参构造+带所有参数的构造器+getter/setter+toString()
    public Employee() {
    }

    public Employee(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
