package com.seecen.day02.EmployeesManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 16:28
 */
public class EmployeesManager {
    /*
    * ******思诚员工管理系统******
    * 1.录入员工
    * 2.修改员工信息
    * 3.删除员工
    * 4.查询员工
    * 5.退出
    * */
    public static Scanner sc = new Scanner(System.in);
    public static List<Employee> employees = new ArrayList<>();
    //添加默认存在的三个员工
    static {
        employees.add(new Employee(1,"admin",45));
        employees.add(new Employee(2,"jju",30));
        employees.add(new Employee(3,"seecen",26));
    }

    public static void main(String[] args) {
        do{
            System.out.println(employees);
            System.out.println("******思诚员工管理系统******");
            System.out.println("1.录入员工");
            System.out.println("2.修改员工信息");
            System.out.println("3.删除员工");
            System.out.println("4.查询员工");
            System.out.println("5.退出");
            System.out.print("请输入您要进行的操作(仅限1-5)：");
            int i = sc.nextInt();
            switch (i){
                case 1:
                    add();
                    break;
                case 2:
                    update();
                    break;
                case 3:
                    delete();
                    break;
                case 4:
                    query();
                    break;
                case 5:
                    System.exit(0);
            }
        }while (true);
    }

    private static void query() {
        //输入id查询
    }

    private static void delete() {
        //employees.remove(myEm);
    }

    private static void update() {
        System.out.print("请输入要修改的员工id:");
        int id = sc.nextInt();
        System.out.print("请输入修改后的员工姓名：");
        String name = sc.next();
        System.out.print("请输入修改后的员工年龄：");
        int age = sc.nextInt();
        /*for (Employee employee : employees) {
            if (employee.getId()==id){
                employee.setName(name);
                employee.setAge(age);
            }
        }*/
        //只进行了声明，并没真的创建对象
        Employee myEm = null;
        for (Employee employee : employees) {
            if (employee.getId() == id){
                myEm = employee;
            }
        }
        //如果try代码块里面的代码没有异常，则正常执行，不会运行catch块里面的代码
        //如果try代码块里面的代码发生了异常，则会执行catch块里面的代码
        try{
            myEm.setName(name);
            myEm.setAge(age);
        }catch (NullPointerException e){
            System.err.println("该员工并不存在，请检查输入的id是否有误！");
        }

    }

    private static void add() {
        System.out.print("请输入要添加的员工名:");
        String name = sc.next();
        System.out.println("请输入要添加的员工年龄:");
        int age = sc.nextInt();
        //flag用来标识将要录入的员工信息有没有重复
        //默认没有重复
        boolean flag = false;
        //遍历employees，将里面的每个员工信息都与将要录入的员工信息进行匹配
        for (Employee employee : employees) {
            if (employee.getName().equals(name)&&employee.getAge()==age){
                flag = true;
            }
        }
        //如果flag为true，表示输入的信息重复了，此时应该打印出冲入录入的提示信息
        //并且不将其录入
        //如果flag为false，表示能够正常的进行录入
        if (flag){
            System.err.println("该员工信息已存在，请勿重复录入！");
        }else {
            employees.add(new Employee(employees.size()+1,name,age));
            System.out.println("添加成功！");
        }
    }
}
