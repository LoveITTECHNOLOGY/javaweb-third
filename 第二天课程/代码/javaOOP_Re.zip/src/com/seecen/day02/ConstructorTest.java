package com.seecen.day02;

import com.seecen.day02.extendsPac.Student;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-24 15:42
 */
public class ConstructorTest {
    public static void main(String[] args) {
        Student student = new Student();
        System.out.println(student);
        Student student1 = new Student("101100");
        System.out.println(student1);
        Student student2 = new Student("101102"
                ,"计算机与大数据科学学院","stu2","男"
                ,"362420...");
        System.out.println(student2);
    }
}
