package com.seecen.day01;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-23 15:01
 */
public class Fridge {
    //打开冰箱的方法
    public void open(){
        System.out.println("打开冰箱！");
    }

    //关闭冰箱的方法
    public void close(){
        System.out.println("关闭冰箱！");
    }
}
