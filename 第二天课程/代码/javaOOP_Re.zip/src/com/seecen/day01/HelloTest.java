package com.seecen.day01;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-23 14:42
 */
public class HelloTest {
    public static void main(String[] args) {
        System.out.println("Hello,World!");
    }
}
