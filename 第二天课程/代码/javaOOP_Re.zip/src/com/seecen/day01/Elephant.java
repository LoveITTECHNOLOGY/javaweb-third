package com.seecen.day01;

/**
 * @program: javaOOP_Re
 * @Author: Jim Chan
 * @Description:
 * @create: 2020-11-23 15:01
 */
public class Elephant {
    //大象进入冰箱的方法
    public void in(){
        System.out.println("大象进入冰箱！");
    }
}
